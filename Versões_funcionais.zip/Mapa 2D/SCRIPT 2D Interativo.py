import os
import networkx as nx
import numpy as np
import plotly.graph_objects as go

root_dir = r"C:\Users\leonardo.cruz\OneDrive - Alfa Contabilidade\Área de Trabalho\Nova pasta"
root_dir = root_dir.replace("\\", "/")
nome_dir = os.path.basename(root_dir.rstrip("/\\")).replace("-", " ").title()

G = nx.Graph()
node_info = {}
max_level = 0

# Função para pegar o tamanho
def get_size_kb(path):
    if os.path.isfile(path):
        return os.path.getsize(path) / 1024
    size = 0
    for dirpath, _, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.exists(fp):
                size += os.path.getsize(fp)
    return size / 1024

# Construção do grafo com rel_path como ID
for folder, subfolders, files in os.walk(root_dir):
    rel_path = os.path.relpath(folder, root_dir)
    folder_name = os.path.basename(folder) or folder
    level = rel_path.count(os.sep)
    max_level = max(max_level, level)

    folder_size = get_size_kb(folder)
    total_itens = len(subfolders) + len(files)
    node_info[rel_path] = {
        "name": folder_name,
        "weight": total_itens or 1,
        "level": level,
        "size_kb": folder_size or 1,
        "tipo": "Diretório",
        "qtd_itens": total_itens
    }
    G.add_node(rel_path)

    for subfolder in subfolders:
        sub_rel = os.path.relpath(os.path.join(folder, subfolder), root_dir)
        sub_name = os.path.basename(subfolder)
        sub_path = os.path.join(folder, subfolder)
        sub_size = get_size_kb(sub_path)
        G.add_edge(rel_path, sub_rel)
        node_info[sub_rel] = {
            "name": sub_name,
            "weight": 1,
            "level": level + 1,
            "size_kb": sub_size or 1,
            "tipo": "Diretório",
            "qtd_itens": len(os.listdir(sub_path)) if os.path.exists(sub_path) else 0
        }

    for file in files:
        file_rel = os.path.relpath(os.path.join(folder, file), root_dir)
        file_name = os.path.basename(file)
        file_path = os.path.join(folder, file)
        if os.path.exists(file_path) and len(file_path) < 260:
            try:
                file_size = os.path.getsize(file_path) / 1024
            except FileNotFoundError:
                file_size = 0
            G.add_node(file_rel)
            G.add_edge(rel_path, file_rel)
            node_info[file_rel] = {
                "name": file_name,
                "weight": 1,
                "level": level + 1,
                "size_kb": file_size or 1,
                "tipo": "Arquivo",
                "qtd_itens": "-"
            }

# Gradiente RGB baseado em nível
def gradiente_rgb(level, max_level):
    pct = level / max_level if max_level else 0
    r = min(255, max(0, int(100 + 155 * pct)))
    g = min(255, max(0, int(150 * (1 - pct))))
    b = min(255, max(0, int(255 * (1 - pct))))
    return f'rgb({r},{g},{b})'

def encurtar_caminho(caminho, limite=60):
    if len(caminho) <= limite:
        return caminho
    else:
        return "..." + caminho[-limite:]

# Posicionamento em 2D hierárquico
np.random.seed(42)
pos_2d = {}
for node, info in node_info.items():
    lvl = info["level"]
    x = lvl * 50
    y = np.random.uniform(-20 * (lvl + 1), 20 * (lvl + 1))
    pos_2d[node] = np.array([x, y])

# Criando o gráfico 2D
fig = go.Figure()

# Adicionando nós com hover amigável
for node, coord in pos_2d.items():
    info = node_info[node]
    fig.add_trace(go.Scatter(
        x=[coord[0]], y=[coord[1]],
        mode="markers",
        marker=dict(
            size=np.clip(info["weight"] * 2, 5, 30),
            color=gradiente_rgb(info["level"], max_level)
        ),
        hovertext=(
            f"Nome: {info['name']}<br>"  # Apenas o nome curto no hover
            f"Tipo: {info['tipo']}<br>"
            f"Nível: {info['level']}<br>"
            f"Tamanho: {info['size_kb']:.2f} KB<br>"
            f"Qtd Itens: {info['qtd_itens']}"
        ),
        hoverinfo="text",
        showlegend=False
    ))

# Arestas
for edge in G.edges:
    x_vals = [pos_2d[edge[0]][0], pos_2d[edge[1]][0]]
    y_vals = [pos_2d[edge[0]][1], pos_2d[edge[1]][1]]
    fig.add_trace(go.Scatter(
        x=x_vals, y=y_vals, mode="lines",
        line=dict(color="gray", width=1),
        showlegend=False
    ))

# Legenda dos níveis
for lvl in range(max_level + 1):
    fig.add_trace(go.Scatter(
        x=[None], y=[None],
        mode='markers',
        marker=dict(size=10, color=gradiente_rgb(lvl, max_level)),
        name=f'Nível {lvl}'
    ))

# Layout
fig.update_layout(
    title=dict(
        text=f"Representação Bidimensional {encurtar_caminho(root_dir)}",
        x=0.5,
        xanchor='center',
        font=dict(size=18)
    ),
    margin=dict(l=0, r=0, b=60, t=40),
    xaxis=dict(visible=False),
    yaxis=dict(visible=False),
    annotations=[
        dict(
            text="Desenvolvido por Leonardo Cruz e Gabriel Inácio - Projeto Indexalfa 2025 | Alfa Contabilidade",
            x=0.5,
            y=0,
            xref='paper',
            yref='paper',
            showarrow=False,
            font=dict(size=12, color="gray"),
            xanchor='center',
            yanchor='bottom'
        )
    ]
)

# Exporta para HTML
html_file = f"mapa_2d_{nome_dir.lower().replace(' ', '_')}.html"
fig.write_html(html_file)
print(f"Mapa salvo como: {html_file}")