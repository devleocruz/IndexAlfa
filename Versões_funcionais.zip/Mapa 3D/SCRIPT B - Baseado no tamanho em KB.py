import os
import networkx as nx
import numpy as np
import plotly.graph_objects as go

root_dir = r"C:\Users\leonardo.cruz\OneDrive - Alfa Contabilidade\Área de Trabalho\Nova pasta"
root_dir = root_dir.replace("\\", "/")
nome_dir = os.path.basename(root_dir.rstrip("/\\")).replace("-", " ").title()

G = nx.Graph()
node_info = {}
max_level = 0

def calcular_nivel(folder):
    rel_path = os.path.relpath(folder, root_dir)
    return rel_path.count(os.sep)

def get_folder_size(path):
    total_size = 0
    if os.path.isfile(path):
        return os.path.getsize(path)
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.exists(fp):
                total_size += os.path.getsize(fp)
    return total_size

for folder, subfolders, files in os.walk(root_dir):
    rel_path = os.path.relpath(folder, root_dir)
    folder_name = os.path.basename(folder) or folder
    level = calcular_nivel(folder)
    max_level = max(max_level, level)
    folder_size = get_folder_size(folder) / 1024

    G.add_node(rel_path)
    node_info[rel_path] = {
        "name": folder_name,
        "size_kb": folder_size or 1,
        "level": level,
        "tipo": "Diretório",
        "caminho": folder,
        "qtd_itens": len(subfolders) + len(files)
    }

    for subfolder in subfolders:
        sub_rel = os.path.relpath(os.path.join(folder, subfolder), root_dir)
        sub_name = os.path.basename(subfolder)
        sub_path = os.path.join(folder, subfolder)
        sub_size = get_folder_size(sub_path) / 1024
        G.add_edge(rel_path, sub_rel)
        node_info[sub_rel] = {
            "name": sub_name,
            "size_kb": sub_size or 1,
            "level": level + 1,
            "tipo": "Diretório",
            "caminho": sub_path,
            "qtd_itens": len(os.listdir(sub_path)) if os.path.exists(sub_path) else 0
        }

    for file in files:
        file_rel = os.path.relpath(os.path.join(folder, file), root_dir)
        file_name = os.path.basename(file)
        file_path = os.path.join(folder, file)
        if os.path.exists(file_path) and len(file_path) < 260:
            try:
                file_size = os.path.getsize(file_path) / 1024
            except FileNotFoundError:
                file_size = 0
            G.add_node(file_rel)
            G.add_edge(rel_path, file_rel)
            node_info[file_rel] = {
                "name": file_name,
                "size_kb": file_size or 1,
                "level": level + 1,
                "tipo": "Arquivo",
                "caminho": file_path,
                "qtd_itens": "-"
            }

# Organizar nós por nível
levels = {}
for node, info in node_info.items():
    lvl = info["level"]
    levels.setdefault(lvl, []).append(node)

def compute_positions(levels):
    pos = {}
    alpha = 1.8
    beta = 0.4
    z_offset = 5
    for level, nodes in levels.items():
        num_nodes = len(nodes)
        radius = np.log(num_nodes + 1) * alpha + 5
        angle_offset = level * beta
        for i, node in enumerate(nodes):
            theta = 2 * np.pi * (i / max(1, num_nodes)) + angle_offset
            x = radius * np.cos(theta)
            y = radius * np.sin(theta)
            z = level * (np.log(num_nodes + 1) + z_offset)
            pos[node] = (x, y, z)
    return pos

pos_3d = compute_positions(levels)

def gradiente_por_tamanho(size_kb, max_size):
    pct = size_kb / max_size if max_size else 0
    r = min(255, max(0, int(100 + 155 * pct)))
    g = min(255, max(0, int(150 * (1 - pct))))
    b = min(255, max(0, int(255 * (1 - pct))))
    return f'rgb({r},{g},{b})'

max_size_kb = max([info["size_kb"] for info in node_info.values()])

fig = go.Figure()

for node, coord in pos_3d.items():
    info = node_info[node]
    size_kb = info["size_kb"]
    lvl = info["level"]
    tipo = info["tipo"]
    qnt_itens = info["qtd_itens"]
    nome_curto = info["name"]

    fig.add_trace(go.Scatter3d(
        x=[coord[0]], y=[coord[1]], z=[coord[2]],
        mode="markers",
        marker=dict(
            size=np.clip(size_kb / max_size_kb * 30, 5, 30),
            color=gradiente_por_tamanho(size_kb, max_size_kb)
        ),
        hovertext=f"Nome: {nome_curto}<br>Tipo: {tipo}<br>Nível: {lvl}<br>Tamanho: {size_kb:.2f} KB<br>Qtd Itens: {qnt_itens}",
        hoverinfo="text",
        showlegend=False
    ))

for edge in G.edges:
    x_vals = [pos_3d[edge[0]][0], pos_3d[edge[1]][0]]
    y_vals = [pos_3d[edge[0]][1], pos_3d[edge[1]][1]]
    z_vals = [pos_3d[edge[0]][2], pos_3d[edge[1]][2]]
    fig.add_trace(go.Scatter3d(
        x=x_vals, y=y_vals, z=z_vals, mode="lines",
        line=dict(color="gray", width=1),
        showlegend=False
    ))

for i in range(5):
    frac = i / 4
    fake_size = frac * max_size_kb
    fig.add_trace(go.Scatter3d(
        x=[None], y=[None], z=[None],
        mode='markers',
        marker=dict(size=10, color=gradiente_por_tamanho(fake_size, max_size_kb)),
        name=f'{int(frac * 100)}% do maior tamanho'
    ))

def encurtar_caminho(caminho, limite=60):
    if len(caminho) <= limite:
        return caminho
    else:
        return "..." + caminho[-limite:]

fig.update_layout(
    title=dict(
        text=f"Representação Tridimensional {encurtar_caminho(root_dir)}",
        x=0.5,
        xanchor='center',
        font=dict(size=18)
    ),
    margin=dict(l=0, r=0, b=60, t=40),
    scene=dict(
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        zaxis=dict(visible=False)
    ),
    annotations=[
        dict(
            text="Desenvolvido por Leonardo Cruz e Gabriel Inácio - Projeto Indexalfa 2025 | Alfa Contabilidade",
            x=0.5,
            y=0,
            xref='paper',
            yref='paper',
            showarrow=False,
            font=dict(size=12, color="gray"),
            xanchor='center',
            yanchor='bottom'
        )
    ]
)

html_file = f"mapa_tamanho_kb_{nome_dir.lower().replace(' ', '_')}_espiral.html"
fig.write_html(html_file)
print(f"Mapa salvo como: {html_file}")